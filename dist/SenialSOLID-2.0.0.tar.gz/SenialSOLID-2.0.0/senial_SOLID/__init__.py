__author__ = 'voval'
__project__ = 'SeniaSOLID'