from setuptools import setup
import procesador

setup(
    name='procesador',
    version=procesador.__version__,
    description='Modulo de defincion del procesamiento',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['procesador'],
)
