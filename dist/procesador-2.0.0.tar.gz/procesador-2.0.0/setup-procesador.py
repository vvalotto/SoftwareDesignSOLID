from setuptools import setup

setup(
    name='procesador',
    version='2.0.0',
    description='Modulo de defincion del procesamiento',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['procesador'],
)
