__author__ = 'Victor Valotto'
__version__ = '1.1.0'