from setuptools import setup
import modelo

setup(
    name='modelo',
    version=modelo.__version__,
    description='Definicion de las entidades',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['modelo'],
)
